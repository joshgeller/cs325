CS352 Group 2 Project 1
Tim Thomas <thomasti@oregonstate.edu>
Kimberly McLeod <mcleodki@oregonstate.edu>
Josh Geller <gellerj@oregonstate.edu>

******************************************

To compile and execute, run the following command:

python proj1_main.py

This will run all four algorithms against MSS_Problems.txt and output the results to MSS_Results.txt.
